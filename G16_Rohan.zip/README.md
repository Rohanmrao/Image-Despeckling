# ML assisted despeckling of SAR images (DIP (UE20EC317) project)
Predicting the appropriate kernel size(Lee filter) for a given speckled SAR image based on it's HSV values, using decision tree regression.

Post-processing using unsharp masking has also been implemented. 

SAR images: https://www.kaggle.com/code/samvram/flood-detection-sar/data
